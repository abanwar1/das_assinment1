#include<stdio.h>
#include<stdlib.h>
#include <stdbool.h>

struct node {
	int data;
	struct node *next;
};
struct node* createNode(int data) {
    struct node* newNode = (struct node*) malloc(sizeof(struct node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}
struct node *head=0,*temp,*head2=0;
struct node* createLinkedList(int size) {
    int i, data;
    struct node *head, *curr;

    printf("Enter data for node 1: ");
    scanf("%d", &data);
    head = createNode(data);
    curr = head;

    for (i = 2; i <= size; i++) {
        printf("Enter data for node %d: ", i);
        scanf("%d", &data);
        curr->next = createNode(data);
        curr = curr->next;
    }

    return head;
}
int length(void);
//void  creat(void);
void display();
void insert_front();
void insert_end();
void insert_kth();
void insert_after_given_value();
void insert_before_kth();
void insert_before_element();
void delete_1st_node();
void delete_last_node();
void delete_after_kth_node();
void delete_before_kth_node();
void delete_kth_node();
void delete_on_value();
void revers_list();
void Sort_lis();
void Search_element();
void Merge_two_lists();
void Concatenate(); 
int lists_equal();

int main(){
	bool bol;
	int ch,size;
	while(1){
	printf("\n\n1. Create a linked list. \n2. Print the content of the list.  \n3. Insert an element at the front of the list \n4. Insert an element at the end of the list\n5. Insert a node after the kth node. \n6. Insert a node after the node (first from the start) containing a given value\n7. Insert a node before the kth node. \n8. Insert a node before the node (first from the start) containing a given value \n9.Delete the first node.\n10. Delete the last node.\n11.Delete a node after the kth node.\n12. Delete a node before the kth node.\n13.Delete kth node \n14.Delete the node(first from the start) containing a specified value\n15. Find the reverse of a list(not just printing in reverse).\n16.Sort the lis\n17.Search a given element\n18.Merge two lists; those are in ascending order.\n19.Concatenate two list\n20.Find if two lists are equal(Boolean output)\n0.Exit\n");
	scanf("%d",&ch);
		switch(ch){
			case 1:
				printf("Enter the size you want to in the linked list ");
				scanf("%d", &size);
				head = createLinkedList(size);
				printf("Linked list created successfully.\n");
				break;

			case 2:
				display();
				break;
			case 3:
				insert_front();
				break;
			case 4:
				insert_end();
				break;
			case 5:
				insert_kth();
				break;
			case 6:
				insert_after_given_value();
				break;
			case 7:
				insert_before_kth();
				break;
			case 8:
				insert_before_element();
				break;
			case 9:
				delete_1st_node();
				break;
			case 10:
				delete_last_node();
				break;
			case 11:
				delete_after_kth_node();
				break;
			case 12:
				delete_before_kth_node();
				break;
			case 13:
				delete_kth_node();
				break;
			case 14:
				delete_on_value();
				break;
			case 15:
			    revers_list();
				break;
			case 16:
				Sort_lis();	
				printf("\n return short ");			
				break;	
			case 17:
				Search_element();
				break;
			case 18:
				Merge_two_lists();
				break;
			case 19:
				Concatenate();
				break;
			case 20:
				bol = lists_equal();
				printf("\n that two list is equal is ")	;
				if(bol){
					printf(" TRUE \n\n");
				}
				else{
					printf(" FALSE\n\n ");
				}			
				break;	
			case 0:
				return 0;
				break;
			default :
				printf("\n\n plese enter wright option  \n ");		
		}
	}
	return 0;
}



int lists_equal(){
	int choose=1,count=0,len=0,x,i;
	struct node *newnode;
	printf(" \n your 1st list is  ");
	display();
	printf("\n\n plz entr the element on the second list  ");
	{
	printf("\n create a new list \n ");
	while(1){
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->next=NULL;
	printf("\nenter data : ");
	scanf("%d",&newnode->data);
	if(head2==0){
		head2=temp=newnode;
	}
	else{
		temp->next=newnode;
		temp=newnode;
		
	}
	printf("\n\n enter '1' for enter new data ");
	scanf("%d",&choose);
	if(choose !=1){
		break;
		}
	}
   }
   
  printf("\n\n your 2nd string is ");
  temp=head2;
  while(temp!= NULL){
  	printf("  %d ",temp->data);
  	count++;
  	temp =  temp->next;
  } 
  len=length();
  temp=head;
  newnode=head2;
  if(len == count){
  	for(i=0;i<len;i++){
  		if(temp->data != newnode->data){
  			x=0;
			  break;
  			
		  }
  		temp=temp->next;
  		newnode=newnode->next;
  		x=1;
	  }
  	
  }
  else{
  	x=0;
  }
  return x;
}
void Concatenate(){
	struct node *newnode;
	int choose=1,len2=0,max,i,j;
	{
	printf("\n create a new list \n ");
	while(1){
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->next=NULL;
	printf("\nenter data : ");
	scanf("%d",&newnode->data);
	if(head2==0){
		head2=temp=newnode;
	}
	else{
		temp->next=newnode;
		temp=newnode;
		
	}
	printf("\n\n enter '1' for enter new data ");
	scanf("%d",&choose);
	if(choose !=1){
		break;
		}
	}
   }
	printf(" \n your 1st list is  ");
	display();
	printf("\n the second list is  ");
	temp=head2;
	while(temp != NULL){
		printf(" %d  ",temp->data);
		temp=temp->next;
		
	}
	
	temp=head;
	while(temp != NULL){
		
		newnode=temp;
		temp=temp->next;
		
	}
	temp=newnode;	
	temp->next=head2;
	printf("\n\n Concatenate 1 st and  2nd list  ");
	display();
	printf("\n\n Concatenate is sucessful \n\n");
}
void Merge_two_lists(){
	struct node *newnode;
	int choose=1,len2=0,max,i,j;
	{
	printf("\n create  a new list \n ");
	while(1){
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->next=NULL;
	printf("\nenter data : ");
	scanf("%d",&newnode->data);
	if(head2==0){
		head2=temp=newnode;
	}
	else{
		temp->next=newnode;
		temp=newnode;
		
	}
	printf("\n\n enter '1' for enter new data ");
	scanf("%d",&choose);
	if(choose !=1){
		break;
		}
	}
   }
	printf(" \n your 1st list is  ");
	display();
	printf("\n the second list is  ");
	temp=head2;
	while(temp != NULL){
		printf(" %d  ",temp->data);
		temp=temp->next;
		len2++;
	}
	Sort_lis();
	temp=head2;
	max=temp->data;
	for(i=0;i<len2;i++){
		temp=head2;
		for(j=0;j<len2-i-1;j++){
			newnode=temp;
			temp=temp->next;
			if(temp->data <newnode->data){
				max=newnode->data;
				newnode->data=temp->data;
				temp->data=max;
			}
		}
	}
	printf(" \n after short  1st list is  ");
	display();
	printf("\n after short the second list is  ");
	temp=head2;
	while(temp != NULL){
		printf( "  %d ",temp->data);
		temp=temp->next;
	}
	temp=head;
	while(temp != NULL){
		newnode=temp;
		temp=temp->next;
		
	}
	temp=newnode;	
	temp->next=head2;
	printf("\n\n march the 2nd list after 1st list  ");
	display();
	printf("\n\n after short the march list is ");
	Sort_lis();
	display();
	printf("\n mearch sucessfully \n\n");


}

void Search_element(){
	int num,len,count=0;
	temp=head;
	printf("\n plz enter the element which you whant to search ");
	scanf("%d",&num);
	len=length();
	while(temp != NULL){
		if(temp->data==num){
			printf("\n %d that element found in the liest \n\n ",num);
			break;
		}
		temp=temp->next;
		count++;
	}
	if(len>count){
		printf("\n\n search element task perform sucessfully \n\n");
	}
	else{
		printf("\n\n %d that element not found in that list ",num);
	}
}



void revers_list(){		
	
   struct node *previous = NULL;
   struct node  *current = head;
   struct node  *next = NULL;

    while (current)
    {
        next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }
    head = previous;

	
}



void Sort_lis(){
	int i,max,l,j;
	struct node *temp,*newnode;
	temp=head;
	max=temp->data;
	l= length();
	for(i=0;i<l;i++){
		temp=head;
		for(j=0;j<l-i-1;j++){
			newnode=temp;
			temp=temp->next;
			if(temp->data <newnode->data){
				max=newnode->data;
				newnode->data=temp->data;
				temp->data=max;
			}
		}
	}
	
}


void delete_on_value(){ 
		int num,count=1,i=1,ind=0,eqal=0;
	struct node *more,*newnode;
	
	temp=head;
	
	printf("\n enter the numbe which you want to delete : ");
	scanf("%d",&num);
	while(temp!=NULL){
		if(temp->data==num){
			eqal=i;
			break;
		}
		
		i++;
		temp=temp->next;
	}
	
	if(eqal==0){
		printf("\n that element is not present in node \n");
	
	}
	else if(eqal==1){
		delete_1st_node();
	}
	else{
	temp=head;
		while(temp!=NULL){
			count++;
			if(count==eqal){
				more=temp;
				more =more->next;
				temp->next=more->next;
				free(more);
				printf("\n delete %d position is sucessfully \n\n",num);
				break;
			}
			
			temp=temp->next;
			
		}
	}
}
void delete_before_kth_node(){
	
	int num,count=2;
	struct node *more,*newnode;
	
	temp=head;
	
	printf("\n enter the node numbe which you want to delete : ");
	scanf("%d",&num);
	if(num<2){
		printf("\n\n therer have not zeroth node please choose correct node \n");
	}
	else if( num==2){
		delete_1st_node();
	}
	else{
		while(temp!=NULL){
			count++;
			if(count==num){
				newnode=more=temp;
				more =more->next;
				temp->next=more->next;
				free(more);
				printf("\n delete before %d position is sucessfully \n\n",num);
				break;
			}
			
			temp=temp->next;
			
		}
	}
	printf("\n\n pleace choose the valide node ");
	
}
void delete_after_kth_node(){ 
	int num,count=0;
	struct node *more,*newnode;
	
	temp=head;
	
	printf("\n enter the node numbe which you want to delete : ");
	scanf("%d",&num);
		while(temp!=NULL){
			count++;
			if(count==num){
				newnode=more=temp;
				more =more->next;
				temp->next=more->next;
				free(more);
				printf("\n delete after %d position is sucessfully \n\n",num);
				break;
			}
			
			temp=temp->next;
			
		}
	printf("\n\n pleace choose the valide node ");
}
void delete_kth_node(){
	int num,count=1;
	struct node *more,*newnode;
	
	temp=head;
	
	printf("\n enter the node numbe which you want to delete : ");
	scanf("%d",&num);
	if(num==1){
		delete_1st_node();	
	}
	else{
		while(temp!=NULL){
			count++;
			if(count==num){
				newnode=more=temp;
				more =more->next;
				temp->next=more->next;
				free(more);
				printf("\n delete %d position is sucessfully \n\n",num);
				break;
			}
			
			temp=temp->next;
			
		}
	
	}
	
}
void delete_last_node(){
	struct node *d_node;	temp=head;
	while(temp->next !=NULL){
		d_node=temp;
		temp=temp->next;
	}
	d_node->next=NULL;
	free(temp);
	printf("\n\n delete last node sucessfully  \n\n");
}
void delete_1st_node(){
	struct node *newnode;
	newnode=temp=head;
	head=temp->next;
	free(newnode);
	printf("\n\n delete 1st node sucessfully \n\n");
}
void insert_before_element(){
	int lock=0,count=0,i=0,num;
	struct node *newnode,*before;
	newnode=(struct node*)malloc(sizeof(struct node ));
	temp=head;
	printf("\n enter data for find in the lis :  ");
	scanf("%d",&num);
	while(temp!=NULL){
		lock++;
		if(num==temp->data){
			break;
		}
		temp=temp->next;
	}

	temp=head;
	printf("\n\n location is %d ",lock);
	while(1){

		if(0<lock){
			while(temp!=NULL){
				if(lock==1){
					printf("\n\n enter the data which you insert before %d   ",num);
					scanf("%d",&newnode->data);
					newnode->next=temp;
		
					head=newnode;
					break;
				}
				
				if(count==lock-2){
					printf("\n\n enter the data which you insert before %d   ",num);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				temp=temp->next;
				count++;
				
			}
			break;
		}
		printf("\n\n enter valid location  ");
	}
}
void insert_before_kth(){
	int lock,count=0;
	struct node *newnode,*before;
	newnode=(struct node*)malloc(sizeof(struct node ));
	temp=head;
	printf("\n enter the node  :  ");
	scanf("%d",&lock);
	while(1){
	
		if(0<lock){
			while(temp!=NULL){
				if(lock==1){
					printf("\n\n enter the data which you insert before %d node  ",lock);
					scanf("%d",&newnode->data);
					newnode->next=temp;
		
					head=newnode;
					break;
				}
				
				if(count==lock-2){
					printf("\n\n enter the data which you insert before %d node  ",lock);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				temp=temp->next;
				count++;
				
			}
			break;
		}
		printf("\n\n enter valid location  ");
	}
}
void insert_after_given_value(){
	int i=0,num;
	int count=0;
	
	struct node *newnode;
	temp=head;
	printf("\n enter data for find in the lis :  ");
	scanf("%d",&num);
	while(temp!=NULL){
		i++;
		if(num==temp->data){
			break;
		}
		temp=temp->next;
	}
	
	newnode=(struct node*)malloc(sizeof(struct node ));
	temp=head;
	while(1){
	
		if(0<i){
			while(temp!=NULL){
				if(i==1){
					printf("\n enter the element for adding after %d  node  ",num);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				
				if(count==i-1){
					printf("\n enter the element for adding after %d  node  ",num);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				temp=temp->next;
				count++;
				
			}
			break;
		}
		
	}
}
void insert_kth(){
	int lock,count=0;
	struct node *newnode;
	newnode=(struct node*)malloc(sizeof(struct node ));
	temp=head;
	while(1){
	printf("\n enter the position of insert node   ");
	scanf("%d",&lock);
		if(0<lock){
			while(temp!=NULL){
				if(lock==1){
					printf("\n\n enter the data which you insert after %d node  ",lock);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				
				if(count==lock-1){
					printf("\n\n enter the data which you insert after %d node  ",lock);
					scanf("%d",&newnode->data);
					newnode->next=temp->next;
		
					temp->next=newnode;
					break;
				}
				temp=temp->next;
				count++;
				
			}
			break;
		}
		printf("\n\n enter valid location  ");
	}
	
}
void insert_end(){
	struct node *newnode;
	temp=head;
	
	newnode=(struct node*)malloc(sizeof(struct node ));
	printf("\n enter data which you want to add last  node  :  ");
	scanf("%d",&newnode->data);
	newnode->next=NULL;
	while(temp->next!=NULL){
		temp=temp->next;
	}
	temp->next=newnode;
	
}
void insert_front(){
	struct node *newnode;
	newnode=(struct node*)malloc(sizeof(struct node ));
	printf("\n enter data which want to fast node :  ");
	scanf("%d",&newnode->data);
	newnode->next=head;
	head=newnode;
}
void display(){
	temp=head;
	printf(" \n\n the list is :  ");
	if(head==0){
		printf(" empty \n\n");
	}
	else{
	while(temp!=NULL){
		printf("  %d ",temp->data);
		temp=temp->next;
	}
	printf("\n\n");
	}
}
void creat(){
	struct node *newnode;
	int choose=1;
	while(1){
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->next=NULL;
	printf("\nenter data : ");
	scanf("%d",&newnode->data);
	if(head==0){
		head=temp=newnode;
	}
	else{
		temp->next=newnode;
		temp=newnode;
		
	}
	printf("\n\n enter '1' for enter new data ");
	scanf("%d",&choose);
	if(choose !=1){
		break;
	}
	}
}
int length(){
	int count=0;
	struct node *temp;
	temp=head;
	while(temp != NULL){
		temp=temp->next;
		count++;
	}
	return count;
}
